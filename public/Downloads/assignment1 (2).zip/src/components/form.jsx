import { useEffect } from "react"
import { useState } from "react"
import "./form.css"

const Form=()=>{

const [user,setUser]=useState({})
const [popup,setPopup]=useState(false)
    console.log(user)
    const registration=()=>{
            
        const first_name_error=document.getElementById("first-name")
        const last_name_error=document.getElementById("last-name")
        const email_error=document.getElementById("email")
        if(!user.first_name){
        first_name_error.innerText="please enter First Name!"
        }
        if(!user.last_name){
            last_name_error.innerText="please enter Last Name!"
        }
        if(!user.email){
            email_error.innerText="please enter an email!"
        }
        else{
            setPopup(true)
            first_name_error.innerText=""
            last_name_error.innerText=""
            email_error.innerText=""
        }
        

    }
    return(
        <>
        <div id="main-conatiner">
            {popup?<div id="display">
                 Success!,Thanks for Registering.
            </div>:<div></div>}
            
            <input type="text" placeholder="First Name"
            onChange={(e)=>{setUser({...user,first_name:e.target.value})}}
            />
            <p id="first-name"></p>
            <input type="text" placeholder="Last Name" 
            onChange={(e)=>{setUser({...user,last_name:e.target.value})}}
            />
            <p id="last-name"></p>
            <input type="email" placeholder="Email" 
            onChange={(e)=>{setUser({...user,email:e.target.value})}}
            />
            <p id="email"></p>
            <button onClick={registration}>Register</button>
        </div>
        </>
    )
}
export default Form