import React from 'react';
import Mypage from './components/Mypage';

function App() {
  return (
    <Mypage/>
  );
}

export default App;
