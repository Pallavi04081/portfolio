import React from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import {Carousel} from "react-responsive-carousel"
// import "./Mypage.css"
const Mypage=()=>{
    return(
        <>
        <div id="main-container" style={{maxHeight:"100px"}}>
            <Carousel>
                <img src={require("./images/curousel1.jpg")} />
                <img src={require("./images/curousel2.jpg")} />
                <img src={require("./images/curousel3.jpg")} />
                <img src={require("./images/curousel4.jpg")} />
            </Carousel>
        </div>
        </>
    )
}
export default Mypage