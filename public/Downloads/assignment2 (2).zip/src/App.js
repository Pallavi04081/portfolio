import logo from './logo.svg';
import './App.css';
import Form from './components/form';

function App() {
  return (
    <Form/>
  );
}

export default App;
