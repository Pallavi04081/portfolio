import { useState } from "react"
import "./form.css"
const Form = () => {

    const [user, setUSer] = useState({checked:false})
    console.log(user)
    return (
        <>

            <div id="main-container">
                <div></div>
                <p>Name:</p>
                <input type="text" name="name"
                    onChange={(e) => { setUSer({ ...user, name: e.target.value }) }} />
                <p>Age:</p>
                <input type="number" name="number"
                    onChange={(e) => { setUSer({ ...user, age: e.target.value }) }} />
                <p>Gender:</p>
                <div className="gender-box">
                    <input type="radio" name="gender" value="male"
                        onChange={(e) => setUSer({ ...user, gender: e.target.value })}
                    /><h6>Male</h6>
                </div>
                <div className="gender-box">
                    <input type="radio" name="gender" value="Female"
                        onChange={(e) => setUSer({ ...user, gender: e.target.value })}
                    /><h6>Female</h6>
                </div>
                <div className="gender-box">
                    <input type="radio" name="gender" value="Other"
                        onChange={(e) => setUSer({ ...user, gender: e.target.value })}
                    /><h6>Other</h6>
                </div>

                <p>Occupation:</p>
                <select onChange={(e) => setUSer({ ...user, occuption: e.target.value })}>
                    <option value="Frontend" 
                    >Frontend</option>
                    <option value="Backend"
                    >Backend</option>
                    <option value="Full-Stack">Full Stack</option>
                </select>
                <p>Are you cool?</p>
                <div id="check">
                <input type="checkbox"/>
                <p> Off course I'm cool!</p>
                </div>
            </div>
        </>
    )
}
export default Form