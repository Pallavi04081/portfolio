import Temp from "./components/temp";

function App() {
  return (
 <>
 <Temp/>
 </>
  );
}

export default App;
