import React from "react";
import { useState } from "react";
import "./temp.css"
const Temp=()=>{
    const [counter,setCounter]=useState(15)
    return(
        <>
        <div id="main-container">
            {
            counter>25?
            <div id="display1">
                <h1>{counter} °C</h1>
            </div>:
            <div id="display2">
                <h1>{counter} °C</h1>
            </div>
            }
            
            <div id="counter">
                <button onClick={()=>{setCounter(counter+1)}}>+</button>
                <button onClick={()=>{setCounter(counter-1)}}>-</button>
            </div>
        </div>
        </>
    )
}
export default Temp